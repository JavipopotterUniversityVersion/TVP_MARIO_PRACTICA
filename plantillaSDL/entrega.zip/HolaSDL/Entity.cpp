#include "Entity.h"
//void Entity::render()
//{
//	//texture->render();
//}
//
//void Entity::update()
//{
//
//}
//
//void Entity::hit()
//{
//
//}

//Entity::Entity(Game* game, int x, int y, int vidas, Texture* text) : game(game), vidas(vidas), texture(text)
//{
//	direction = 0;
//	position.Set(x, y);
//}