#pragma once
class Moneda
{
};

