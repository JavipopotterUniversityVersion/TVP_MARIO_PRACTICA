#include "SDLError.h"

//SDLError::SDLError(const string& what_arg) : GameError(what_arg)
//{
//
//}