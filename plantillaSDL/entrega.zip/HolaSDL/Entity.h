#pragma once
class Game;

class Entity
{
	/*protected:
		Vector2D<int> position;
		int direction;
		Texture* texture;
		Game* game;
		int vidas;

	public:
		Entity(Game* game, int x, int y, int vidas, Texture* text);
		void render();
		virtual void update();
		virtual void hit();*/
};

