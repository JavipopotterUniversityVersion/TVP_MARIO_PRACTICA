#pragma once
#include "GameError.h"
using namespace std;

class FileFormatError : public GameError
{

};

