class Dog
{
};
