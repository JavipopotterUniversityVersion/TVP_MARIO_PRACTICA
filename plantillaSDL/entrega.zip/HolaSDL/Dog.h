class Dog
{
};
